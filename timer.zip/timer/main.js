const{app,BrowserWindow,Tray,Menu,ipcMain} =require('electron');
const Positioner = require('electron-positioner');
const path = require('path');
let tray;
let trayIcon;
let icoWhite = path.join(__dirname, 'Icon-white.png');
let htmlPath = `file://${__dirname}/index.html`;
app.on('ready',(bounds)=>{
   tray = new BrowserWindow({
    show: false,
    frame: false,
    resizable: false,
    movable: false,
    scroll:false,
    scrollBounce: false,
    width:600,
    height:210

  })
  // app.dock.hide();
  tray.loadURL(htmlPath);
  tray.on('blur',()=>{
    tray.hide();
  })
  let trayIcon = new Tray(icoWhite);
  trayIcon.on('click',(e,bounds)=>{
    if(tray.isVisible()){
      tray.hide();
    }else{
    let positioner = new Positioner(tray);
    positioner.move('trayCenter',bounds);
    tray.show();}


  })
ipcMain.on('exit',()=>{
  app.quit();
})
ipcMain.on('sub',(event,h_num,m_num)=>{
  setTimeout(function m_counter(){
    if(m_num>0){
      m_num-=1;
      console.log(`${h_num}:${m_num}`);
      setTimeout(m_counter,1000);
    }else if(m_num===0 && h_num>0){
      h_num-=1;
      m_num+=1;
      console.log(`${h_num}:${m_num}`);
      setTimeout(m_counter,1000);
    }else if(m_num===0 && h_num===0){
      console.log("finish");
    }
  },1000)
  ipcMain.on('stop-counter',(event,h_num,m_num)=>{
  h_num = 0;
  m_num = 0;
  event.sender.send('new-value-counter',h_num,m_num);
})
})





})
